﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memory
{
    public partial class frmMemory : Form
    {
        private int sor = 3;
        private int oszlop = 4;
       
        public frmMemory()
        {
            InitializeComponent();
            // Resource manager létrehozása a lap osztály egy statikus adattagjában
            // Ez tartalmazza a képeket, sorszámmal
            // Van két speciális kép: Hatlap, Ures
            Lap.R = new ResourceManager("Memory.ResMemory", GetType().Assembly);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // 100*100-as képekkel feltöltjük a flowlayoutpanel-t!
            // Ez sorfolytonosan jeleníti meg a képeket, nem kell koordinátát megadni
            // A flowlayoutpanel mérete 3*4-es játékhoz van beállítva, 100*100-as képekkel
            // Ha a sor/oszlop értékeket változtatjuk, 
            // a flowlayoutpanel méretét is változtatni kell

            for (int i = 0; i < sor * oszlop; i++)
            {
                fpPanel.Controls.Add(new Lap(i, 100));
            }
        }
    }
}
