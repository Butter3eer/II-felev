﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Memory
{
    class Lap:PictureBox
    {
        private int sorszam;  // A megjelenítendő kép sorszáma
        private bool megforditva;  // Meg van-e fordítva a kép
        private int meret;  //  A kép mérete pixelben
        private static ResourceManager r;  // A resourse manager, a képek megjelenítéséhez

        public static ResourceManager R
        {
            get
            {
                return r;
            }

            set
            {
                r = value;
            }
        }

        public Lap(int sorszam,int meret)
        {
            this.sorszam = sorszam;
            this.meret = meret;
            this.Width = meret;
            this.Height = meret;
            this.megforditva = false;  // Alaphelyzet: nincs megfordítva
            this.Image = (Bitmap)r.GetObject("Hatlap");  // Hátlappal felfelé
            this.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Click += Lap_Click;
        }

        private void Lap_Click(object sender, EventArgs e)
        {
            // Teszt1
            levesz();
            
            //Teszt2
            //fordit();
            //if (megforditva)
            //{
            //    this.Image = (Bitmap)r.GetObject("_"+(sorszam+1));
            //}
            //else
            //{
            //    this.Image = (Bitmap)r.GetObject("Hatlap");
            //}

        }

        public void fordit()
        {
            this.megforditva = !megforditva;
        }

        public void levesz()
        {
            this.Image = (Bitmap)r.GetObject("Ures");
            // Nem vesszük le ténylegesen

            // Ez hibás lenne!!
            //this.Visible = false; 
        }


    }
}
