﻿namespace KepProba
{
    partial class frmKepkivag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbNagykep = new System.Windows.Forms.PictureBox();
            this.pbKiskep = new System.Windows.Forms.PictureBox();
            this.numSorOszlopDb = new System.Windows.Forms.NumericUpDown();
            this.lblSorDb = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbNagykep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKiskep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSorOszlopDb)).BeginInit();
            this.SuspendLayout();
            // 
            // pbNagykep
            // 
            this.pbNagykep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbNagykep.Location = new System.Drawing.Point(52, 57);
            this.pbNagykep.Name = "pbNagykep";
            this.pbNagykep.Size = new System.Drawing.Size(109, 85);
            this.pbNagykep.TabIndex = 0;
            this.pbNagykep.TabStop = false;
            this.pbNagykep.MouseLeave += new System.EventHandler(this.pbNagykep_MouseLeave);
            this.pbNagykep.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbNagykep_MouseMove);
            // 
            // pbKiskep
            // 
            this.pbKiskep.BackColor = System.Drawing.Color.Transparent;
            this.pbKiskep.Location = new System.Drawing.Point(568, 44);
            this.pbKiskep.Name = "pbKiskep";
            this.pbKiskep.Size = new System.Drawing.Size(98, 144);
            this.pbKiskep.TabIndex = 3;
            this.pbKiskep.TabStop = false;
            // 
            // numSorOszlopDb
            // 
            this.numSorOszlopDb.Location = new System.Drawing.Point(194, 21);
            this.numSorOszlopDb.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.numSorOszlopDb.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numSorOszlopDb.Name = "numSorOszlopDb";
            this.numSorOszlopDb.Size = new System.Drawing.Size(51, 20);
            this.numSorOszlopDb.TabIndex = 4;
            this.numSorOszlopDb.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numSorOszlopDb.ValueChanged += new System.EventHandler(this.numSorOszlopDb_ValueChanged);
            // 
            // lblSorDb
            // 
            this.lblSorDb.AutoSize = true;
            this.lblSorDb.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblSorDb.Location = new System.Drawing.Point(48, 21);
            this.lblSorDb.Name = "lblSorDb";
            this.lblSorDb.Size = new System.Drawing.Size(118, 20);
            this.lblSorDb.TabIndex = 5;
            this.lblSorDb.Text = "Sorok száma:";
            // 
            // frmKepkivag
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 663);
            this.Controls.Add(this.lblSorDb);
            this.Controls.Add(this.numSorOszlopDb);
            this.Controls.Add(this.pbKiskep);
            this.Controls.Add(this.pbNagykep);
            this.Name = "frmKepkivag";
            this.Text = "Képrészlet kivágása";
            this.Load += new System.EventHandler(this.frmKepkivag_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbNagykep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKiskep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSorOszlopDb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbNagykep;
        private System.Windows.Forms.PictureBox pbKiskep;
        private System.Windows.Forms.NumericUpDown numSorOszlopDb;
        private System.Windows.Forms.Label lblSorDb;
    }
}

