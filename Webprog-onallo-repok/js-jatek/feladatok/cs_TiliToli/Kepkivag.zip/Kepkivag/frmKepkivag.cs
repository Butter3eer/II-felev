﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace KepProba
{
    public partial class frmKepkivag : Form
    {
        private Bitmap bitmap = null;
        private int kiskepSzelesseg; 
        private int kiskepMagassag;
        private int sorDb;

        public frmKepkivag()
        {
            InitializeComponent();
            
        }

        private void vonalaz()
        {
            Graphics g = Graphics.FromImage(bitmap);
            Pen p = new Pen(Color.Yellow);
            p.Width = 2;
            for (int i = 1; i < sorDb; i++)
            {
                g.DrawLine(p, new Point(0, i * kiskepMagassag), new Point(bitmap.Width, i * kiskepMagassag));
                g.DrawLine(p, new Point(i * kiskepSzelesseg, 0), new Point(i * kiskepSzelesseg, bitmap.Height));
            }
        }

        private void beallit()
        {
            bitmap = (Bitmap)Image.FromFile("Kepek\\zebra.jpg");
            sorDb=(int)numSorOszlopDb.Value;
            
            pbNagykep.Width = bitmap.Width;
            pbNagykep.Height = bitmap.Height;
            pbNagykep.Image = bitmap;

            kiskepSzelesseg = pbNagykep.Width / sorDb;
            kiskepMagassag = pbNagykep.Height / sorDb;

            pbKiskep.Width = kiskepSzelesseg;
            pbKiskep.Height = kiskepMagassag;
        }

        private void frmKepkivag_Load(object sender, EventArgs e)
        {
            beallit();
            vonalaz();
        }

        private void pbNagykep_MouseLeave(object sender, EventArgs e)
        {
            pbKiskep.Image = null;
        }

        private void pbNagykep_MouseMove(object sender, MouseEventArgs e)
        {
            
            int oszlop = e.X / kiskepSzelesseg;
            int sor = e.Y / kiskepMagassag;
            Text = oszlop+" "+ sor+ " ";
            pbKiskep.Image = bitmap.Clone(new Rectangle(oszlop * kiskepSzelesseg, sor* kiskepMagassag,kiskepSzelesseg,kiskepMagassag), System.Drawing.Imaging.PixelFormat.DontCare);
        }

        private void numSorOszlopDb_ValueChanged(object sender, EventArgs e)
        {
            beallit();
            vonalaz();
        }
           
    }
}
