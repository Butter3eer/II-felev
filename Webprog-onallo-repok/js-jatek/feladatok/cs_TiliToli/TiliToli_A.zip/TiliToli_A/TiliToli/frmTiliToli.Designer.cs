﻿namespace TiliToli
{
    partial class FrmTiliToli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlJatekTerulet = new System.Windows.Forms.Panel();
            this.btnStart = new System.Windows.Forms.Button();
            this.nudMeret = new System.Windows.Forms.NumericUpDown();
            this.lblMeret = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudMeret)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlJatekTerulet
            // 
            this.pnlJatekTerulet.BackColor = System.Drawing.Color.PowderBlue;
            this.pnlJatekTerulet.Location = new System.Drawing.Point(12, 12);
            this.pnlJatekTerulet.Name = "pnlJatekTerulet";
            this.pnlJatekTerulet.Size = new System.Drawing.Size(240, 240);
            this.pnlJatekTerulet.TabIndex = 0;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(12, 269);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            // 
            // nudMeret
            // 
            this.nudMeret.Location = new System.Drawing.Point(208, 272);
            this.nudMeret.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.nudMeret.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.nudMeret.Name = "nudMeret";
            this.nudMeret.Size = new System.Drawing.Size(44, 20);
            this.nudMeret.TabIndex = 1;
            this.nudMeret.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudMeret.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // lblMeret
            // 
            this.lblMeret.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblMeret.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblMeret.Location = new System.Drawing.Point(151, 274);
            this.lblMeret.Name = "lblMeret";
            this.lblMeret.Size = new System.Drawing.Size(53, 18);
            this.lblMeret.TabIndex = 2;
            this.lblMeret.Text = "Méret:";
            // 
            // FrmTiliToli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(270, 307);
            this.Controls.Add(this.lblMeret);
            this.Controls.Add(this.nudMeret);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.pnlJatekTerulet);
            this.Name = "FrmTiliToli";
            this.Text = "TiliToli";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudMeret)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlJatekTerulet;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.NumericUpDown nudMeret;
        private System.Windows.Forms.Label lblMeret;
    }
}

