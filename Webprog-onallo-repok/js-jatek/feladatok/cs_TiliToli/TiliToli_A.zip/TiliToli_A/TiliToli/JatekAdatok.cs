﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TiliToli
{
    class JatekAdatok
    {
        private static int n;
        private static int meret;
        private static int gombokszama;
        
        public static int N { get { return n; } set { n = value; } }
        public static int Meret { get { return meret; } set { meret = value; } }
        public static int Gombokszama { get { return gombokszama; } set { gombokszama=value; } }
        
    }
}
