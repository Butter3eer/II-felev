﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace TiliToli
{
    class Gomb : Button
    {
        private int sorszam;  // Hányadik helyen van sorfolytonosan
        private int ertek;    // Milyen szám látható rajta

        private int SzamitTop()  // Kiszámolja a sorszámból, és a gomb adataiból a függőleges pozíciót 
        {
            return (sorszam / JatekAdatok.N) * JatekAdatok.Meret;
        }

        private int SzamitLeft() // Kiszámolja a sorszámból, és a gomb adataiból a vízszintes pozíciót
        {
            return (sorszam % JatekAdatok.N) * JatekAdatok.Meret;
        }

        public Gomb(int sorszam, int ertek, Color color)
        {
            this.sorszam = sorszam;  // A gomb sorszáma, sorfolytonosan 
            this.ertek = ertek;      // A gombon látható számérték
            this.Top = SzamitTop();
            this.Left = SzamitLeft();
            this.Text = ertek.ToString();
            this.Width = JatekAdatok.Meret;
            this.Height = JatekAdatok.Meret;
            this.BackColor = color;
            this.Font = new Font("Courier New", 10, FontStyle.Bold);
            this.ForeColor = Color.White;
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 1;
            this.FlatAppearance.BorderColor = Color.PowderBlue;
        }

    }
}
