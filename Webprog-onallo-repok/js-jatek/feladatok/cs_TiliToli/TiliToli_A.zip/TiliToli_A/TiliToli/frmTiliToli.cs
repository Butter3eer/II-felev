﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TiliToli
{
    public partial class FrmTiliToli : Form
    {

        public FrmTiliToli()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Alap();
        }

        public void Beallit()
        {
            JatekAdatok.N = (int)nudMeret.Value; // Sorok száma
            JatekAdatok.Meret = pnlJatekTerulet.Width / JatekAdatok.N;  // Egy gomb mérete pixelekben
            //JatekAdatok.Gombokszama = // A gombok darabszáma
        }


        private void GombFelrak()
        {
            pnlJatekTerulet.Controls.Clear();          
            pnlJatekTerulet.Controls.Add(new Gomb(1, 0, Color.Black));
            pnlJatekTerulet.Controls.Add(new Gomb(5, 4, Color.Red));
            pnlJatekTerulet.Controls.Add(new Gomb(7, 11, Color.Green));
        }

        public void Alap()
        {
            Beallit();
            GombFelrak();
            btnStart.Text = "Start";
            nudMeret.Enabled = true;
        }


        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            Alap();
        }

    }
}
