﻿namespace Pixio
{
    partial class FrmPixio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbKep = new System.Windows.Forms.PictureBox();
            this.btnUj = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbKep)).BeginInit();
            this.SuspendLayout();
            // 
            // pbKep
            // 
            this.pbKep.Location = new System.Drawing.Point(24, 27);
            this.pbKep.Name = "pbKep";
            this.pbKep.Size = new System.Drawing.Size(400, 400);
            this.pbKep.TabIndex = 0;
            this.pbKep.TabStop = false;
            // 
            // btnUj
            // 
            this.btnUj.Location = new System.Drawing.Point(453, 404);
            this.btnUj.Name = "btnUj";
            this.btnUj.Size = new System.Drawing.Size(75, 23);
            this.btnUj.TabIndex = 1;
            this.btnUj.Text = "Új kép";
            this.btnUj.UseVisualStyleBackColor = true;
            this.btnUj.Click += new System.EventHandler(this.btnUj_Click);
            // 
            // FrmPixio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 461);
            this.Controls.Add(this.btnUj);
            this.Controls.Add(this.pbKep);
            this.Name = "FrmPixio";
            this.Text = "Pixio";
            this.Load += new System.EventHandler(this.FrmPixio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbKep)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbKep;
        private System.Windows.Forms.Button btnUj;
    }
}

