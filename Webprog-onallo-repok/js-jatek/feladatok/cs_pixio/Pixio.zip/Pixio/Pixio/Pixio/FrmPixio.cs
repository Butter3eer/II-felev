﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Resources;

namespace Pixio
{
    public partial class FrmPixio : Form
    {
        private ResourceManager resourceManager;
        private string[] nevek = { "Bono", "Kurt_Cobain", "John_Lennon", "Johnny_Depp", "Wayne_Rooney", "Julia_Roberts",
                                    "David_Beckham", "Angelina_Jolie","Rihanna","Roger_Federer","Tiger_Woods" };
        private Random r = new Random();

        public FrmPixio()
        {
            InitializeComponent();
            // A resource fájl betöltése, amelyben a képek vannak
            resourceManager = new ResourceManager("Pixio.ResPixio", GetType().Assembly);
            // A resource fájl tartalmának megtekintése és módosítása: Solution Explorer/ResPixio.resc
        }

        private void FrmPixio_Load(object sender, EventArgs e)
        {
            pbKep.Image = (Bitmap)resourceManager.GetObject(nevek[0]);  // Kép megjelenítése a 0. név alapján
            pbKep.SizeMode = PictureBoxSizeMode.CenterImage;
            Lefed();
        }
       
        // A kép lefedése Button objektumokkal
        private void Lefed()
        {
            pbKep.Controls.Clear();
            int sor = 5;
            for (int i = 0; i < sor; i++)
                for (int j = 0; j < sor; j++)
                {
                    Button b = new Button();
                    b.Width = pbKep.Width / sor; // A gomb szélessége a kép szélességének az ötöde (5 sor esetén)
                    b.Height = b.Width; 
                    b.Top = i * b.Width;
                    b.Left = j * b.Height;
                    b.FlatStyle = FlatStyle.Flat;
                    b.Click += button_Click;  // Click eseménykezelő hozzárendelése
                    pbKep.Controls.Add(b);  // Gomb felrakása a képre
                }
            btnUj.Focus(); // Fókusz az Új kép gombra
        }

        // Egy gomb "leszedése"
        private void button_Click(object sender, EventArgs e)
        {
            (sender as Button).Visible = false;
            btnUj.Focus();
        }
  
        // Új kép kiválasztása a resource fájlból
        private void btnUj_Click(object sender, EventArgs e)
        {  
            pbKep.Image = (Bitmap)resourceManager.GetObject(nevek[r.Next(nevek.Length)]);
            Lefed();
        }

       
    }
}
